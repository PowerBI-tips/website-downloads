This layout contains some data that was not included in the original release of the Power BI file.

Thus, there is an included Data folder with an XLSX file that you can use to populate the Sales data table.

A parameter has been made inside the Query Editor so you can change the Data.xlsx folder location.  For help on using a parameter to pull files from a folder location read the following blog: https://powerbi.tips/2017/03/using-parameters-to-enable-sharing/

Thanks for downloading another Quality layout from PowerBI.tips

Sincerely,
Mike